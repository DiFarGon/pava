# defines the struct PavaException that represents an
# exception instance. it is used to distinguish between Pava 
# exceptions and Julia exceptions, since we use the Julia 
# exception mechanism

struct PavaException
    exception
end

Base.show(io::IO, e::PavaException) = print(io, "Uncaught exception: ", e.exception)