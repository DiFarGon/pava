# defines the structs needed to implement structs in PavaJulia
# PavaStruct defines a struct (name and fields)
# PavaStructInstance represents as instance of a struct described by PavaStruct

struct PavaStruct
    fields::Vector{Symbol}
    name::Symbol
end

struct PavaStructInstance
    structdesc::PavaStruct
    values::Vector{Any}
end

Base.show(io::IO, s::PavaStruct) = print(io, s.name)

function structfield(instance::PavaStructInstance, name::Symbol)
    let pos = findall(s->s == name, instance.structdesc.fields);
        if length(pos) != 0
            instance.values[pos[1]]
        else
            error("field " * string(name) * " not found in " * string(instance.structdesc.name) * " struct.")
        end
    end
end