# defines the methods for the generic function evalcallsym
# this function receives the symbol, the args and the env
# each method applies to a specific symbol/group of symbols
# (for :call expressions)

include("exception.jl")

function evalcallsym(::Val{:+}, funcargs::AbstractArray, env::Env)
    reduce(+, [eval(funcargs[i], env) for i in 1:length(funcargs)])
end

function evalcallsym(::Val{:-}, funcargs::AbstractArray, env::Env)
    if length(funcargs) == 1
        - eval(funcargs[1], env)
    else
        reduce(-, [eval(funcargs[i], env) for i in 1:length(funcargs)]) 
    end
end

function evalcallsym(::Val{:*}, funcargs::AbstractArray, env::Env)
    reduce(*, [eval(funcargs[i], env) for i in 1:length(funcargs)])
end

function evalcallsym(::Val{:/}, funcargs::AbstractArray, env::Env)
    reduce(/, [eval(funcargs[i], env) for i in 1:length(funcargs)])
end

function evalcallsym(::Val{:<}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) < eval(funcargs[2], env)
end

function evalcallsym(::Val{:>}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) > eval(funcargs[2], env)
end

function evalcallsym(::Val{:<=}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) <= eval(funcargs[2], env)
end

function evalcallsym(::Val{:>=}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) >= eval(funcargs[2], env)
end

function evalcallsym(::Val{:(==)}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) == eval(funcargs[2], env)
end

function evalcallsym(::Val{:(!=)}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) != eval(funcargs[2], env)
end

function evalcallsym(::Val{:&&}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) && eval(funcargs[2], env)
end

function evalcallsym(::Val{:||}, funcargs::AbstractArray, env::Env)
    eval(funcargs[1], env) || eval(funcargs[2], env)
end

function evalcallsym(::Val{:!}, funcargs::AbstractArray, env::Env)
    !eval(funcargs[1], env)
end

function evalcallsym(::Val{:throw}, funcargs::AbstractArray, env::Env)
    throw(PavaException(eval(funcargs[1], env)))
end

function evalcallsym(::Val{:getfield}, funcargs::AbstractArray, env::Env)
    if length(funcargs) == 2
        let structinstance = eval(funcargs[1], env),
            field = eval(funcargs[2],env);
            if isa(structinstance, PavaStructInstance) && isa(field, Symbol)
                structfield(structinstance, field)
            else
                error("error accessing struct field.")
            end
        end
    else
        error("getfield takes 2 arguments.")
    end
end

function evalcallsym(::Val{:length}, funcargs::AbstractArray, env::Env)
   let arg = eval(funcargs[1], env);
       if isa(arg, AbstractArray)
           length(arg)
       else
           error("length requires an array.")
       end
   end
end

function evalcallsym(::Val{:fieldnames}, funcargs::AbstractArray, env::Env)
    if length(funcargs) == 1
        let structdesc = eval(funcargs[1], env);
            if isa(structdesc, PavaStruct)
                structdesc.fields
            else
                error("fieldnames requires a struct.")
            end
        end
    else
        error("fieldnames takes 1 argument.")
    end
end

# default: the symbol represents a name, rather than a primitive operation
function evalcallsym(::Val{sym}, funcargs::AbstractArray, env::Env) where sym
    let func = envsearchsym(sym, env);
        if isa(func, PavaFunction)
            evalcall(func, funcargs, env)
        elseif isa(func, PavaStruct) 
            if length(funcargs) == length(func.fields)
                PavaStructInstance(func, map(e->eval(e, env), funcargs))
            else
                throw(string(func.name, " has ", length(func.fields), " fields."))
            end
        else
            throw(string(typeof(func)) * " is not callable.")
        end
    end
end