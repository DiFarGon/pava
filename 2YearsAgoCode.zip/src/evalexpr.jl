# defines the methods for the generic function evalexpr
# this function receives the head, the args and the env
# each method applies to a specific head/group of heads
# it also defines evalcall

include("env.jl")
include("function.jl")
include("evalcallsym.jl")
include("struct.jl")

# when the function being called is a symbol (a primitive operation or a name for a PavaFunction)
function evalcall(sym::Symbol, funcargs::AbstractArray, env::Env)
    evalcallsym(Val(sym), funcargs, env)
end

# when the entity being called is a PavaFunction (literally)
function evalcall(func::PavaFunction, funcargs::AbstractArray, env::Env)
    if length(funcargs) != length(func.params) # TODO currying
        throw("The number of arguments is " * string(length(funcargs)) * 
                ", but the number of parameters is " * string(length(func.params)))
    else
        let evalargs = map((e)->eval(e, env), funcargs),
            newenv = Env(func.env, func.params, evalargs);
            eval(func.body, newenv)
        end
    end
end

# selector for the parameters of a lambda construction
function lambdaparams(args::AbstractArray)
    if isa(args[1], Symbol)
        [args[1]]
    elseif isa(args[1], Expr) && args[1].head == :tuple
        args[1].args
    else
        throw("Error in lambdaparams.")
    end
end

function evalexpr(::Val{:block}, expr::Expr, env::Env)
    for i = 1:(length(expr.args) - 1)
        eval(expr.args[i], env)
    end

    return if length(expr.args) > 0 eval(expr.args[length(expr.args)], env) else nothing end
end

function evalexpr(::Val{:call}, expr::Expr, env::Env)
    let args = expr.args,
        func = if isa(args[1], Symbol) args[1] else eval(args[1], env) end;
        evalcall(func, view(args, 2:length(args)), env)
    end
end    

function evalexpr(::Union{Val{:if}, Val{:elseif}}, expr::Expr, env::Env)
    let args = expr.args,
        guard = eval(args[1], env);
        if guard
            eval(args[2], env)
        else
            length(args) == 2 ? nothing : eval(args[3], env)
        end
    end
end    

function evalexpr(::Val{:function}, expr::Expr, env::Env)
    evalexpr(Val(:(=)), expr, env)
end

function evalexpr(::Val{:(=)}, expr::Expr, env::Env)
    args = expr.args
    # case a = expr
    if isa(args[1], Symbol)
        let result = searchbinding(args[1], env),
            env2 = if result === nothing env else result end;
            envbind(args[1], eval(args[2], env), env2)
        end
    
    # case a(x, y, z...) = expr
    elseif isa(args[1], Expr) && args[1].head == :call
        let args2 = args[1].args,
            name = istopenv(env) ? args2[1] : nothing,
            pavafunc = PavaFunction(view(args2, 2:length(args2)), args[2], env, name),
            result = searchbinding(args2[1], env),
            env2 = if result === nothing env else result end;
            envbind(args2[1], pavafunc, env2)
        end
    
    else
        throw("The left side of an assignment must be a symbol or a call node.")
    end
end    

function evalexpr(::Val{:let}, expr::Expr, env::Env)
    let args = expr.args,
        newenv = Env(env);
        begin 
            eval(args[1], newenv)
            eval(args[2], newenv)
        end
    end
end 

function evalexpr(::Val{:(->)}, expr::Expr, env::Env)
    PavaFunction(lambdaparams(expr.args), expr.args[2], env, nothing)
end 

function evalexpr(::Val{:&&}, expr::Expr, env::Env)
    eval(expr.args[1], env) && eval(expr.args[2], env)
end

function evalexpr(::Val{:||}, expr::Expr, env::Env)
    eval(expr.args[1], env) || eval(expr.args[2], env)
end 

function evalexpr(::Val{:(!)}, expr::Expr, env::Env)
    !eval(expr.args[1], env)
end 

function evalexpr(::Val{:global}, expr::Expr, env::Env)
    args = expr.args[1].args
    # case global a = expr
    if isa(args[1], Symbol)
        envbind(args[1], eval(args[2], env), topenv(env))

    # case global a(x, y, z...) = expr
    elseif isa(args[1], Expr) && args[1].head == :call
        let args2 = args[1].args,
            pavafunc = PavaFunction(view(args2, 2:length(args2)), args[2], env, args2[1]);
            envbind(args2[1], pavafunc, topenv(env))
        end
    
    else
        throw("The left side of an assignment must be a symbol or a call node.")
    end
end

function evalexpr(::Val{:comparison}, expr::Expr, env::Env)
    i = 2
    val = true

    while val && i <= length(expr.args) - 1
        v1 = eval(expr.args[i - 1], env)
        v2 = eval(expr.args[i + 1], env)
        val = val && eval(Expr(:call, expr.args[i], v1, v2), env)
        
        i += 2
    end

    return val
end

function evalexpr(::Val{:try}, expr::Expr, env::Env)
    try 
        let newenv = Env(env);
            eval(expr.args[1], newenv)
        end
    catch e
        if isa(e, PavaException)
            let newenv = Env(env);
                begin
                    if isa(expr.args[2], Symbol)
                        envbind(expr.args[2], e.exception, newenv)
                    end
                    eval(expr.args[3], newenv)
                end
            end
        else
            rethrow(e)
        end
    end
end

function evalexpr(::Val{:struct}, expr::Expr, env::Env)
    let name = expr.args[2],
        fields = filter(e->!isa(e, LineNumberNode), expr.args[3].args);
        envbind(name, PavaStruct(fields, name), topenv(env))
    end
end

function evalexpr(::Val{:.}, expr::Expr, env::Env)
    evalcallsym(Val(:getfield), expr.args, env)
end

function evalexpr(::Val{:ref}, expr::Expr, env::Env)
    let arr = eval(expr.args[1], env),
        index = eval(expr.args[2], env);
        arr[index]
    end
end

function evalexpr(::Val{:vect}, expr::Expr, env::Env)
    map(x->eval(x, env), expr.args)
end

# default: head not recognized, throw error
function evalexpr(::Val{sym}, expr::Expr, env::Env) where sym
    error("Head of expression (" * string(sym) * ") not recognized.")
end