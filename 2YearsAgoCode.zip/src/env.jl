struct Env
    bindings::Dict{Symbol, Any}
    prevenv::Union{Env, Nothing}
end

function Env(prevenv::Env)
    Env(Dict{Symbol, Any}(), prevenv) 
end

function Env()
    Env(Dict{Symbol, Any}(), nothing) 
end

# creates a new env with parameter bindings
function Env(prevenv::Env, params::AbstractArray{Symbol}, args::AbstractArray)
    Env(Dict{Symbol, Any}(zip(params, args)), prevenv)
end

# get the value of the sym in env (and parents)
function envsearchsym(sym::Symbol, env::Env)
    if sym in keys(env.bindings)
        env.bindings[sym]
    elseif !(env.prevenv === nothing)
        envsearchsym(sym, env.prevenv)
    else
        throw("Symbol " * string(sym) * " not found in the current env.")
    end
end

# bind sym to val in env
function envbind(sym::Symbol, val, env::Env)
    env.bindings[sym] = val
end

# returns the env with pi and e (top; no parent)
function initialenv()
    Env(Dict(:pi => 3.14159, :e => 2.17828), nothing)
end

# returns the env where there is the sym is bound (other than the top most)
function searchbinding(sym::Symbol, inner::Env)::Union{Env, Nothing}
    if inner.prevenv === nothing # topmost env
        nothing
    else        
        if sym in keys(inner.bindings)
            inner
        else
            searchbinding(sym, inner.prevenv)
        end
    end
end

# returns the top env of an inner env
function topenv(env::Env)::Env
    if env.prevenv === nothing
        env
    else
        topenv(env.prevenv)
    end
end

# returns true if the env is the top env
function istopenv(env::Env)::Bool
    env.prevenv === nothing    
end