# defines the struct PavaFunction that is used to represent a function
# it saves the body, parameters, the env in which it was defined and 
# its name (if it has a name) for printing purposes

include("env.jl")

struct PavaFunction
    params::Vector{Symbol}
    body
    env::Env
    name::Union{Symbol, Nothing}
end

Base.show(io::IO, f::PavaFunction) = print(io, f.name == nothing ? "<anonymous function>" : string(f.name))