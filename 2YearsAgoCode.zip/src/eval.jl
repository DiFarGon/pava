# defines the methods for the generic function
# eval(e, env)

include("evalexpr.jl")

SelfEvaluating = Union{Number, 
                       Bool, 
                       AbstractArray,
                       AbstractString, 
                       PavaFunction, 
                       PavaStruct, 
                       PavaStructInstance, 
                       Symbol}

# ignore LineNumberNode 
function eval(::LineNumberNode, env::Env)
    nothing    
end

# eval symbols by search the env
function eval(sym::Symbol, env::Env)
    envsearchsym(sym, env)
end

# self evaluating expressions does not need evaluation
function eval(expr::SelfEvaluating, env::Env)
    expr
end

# eval expressions (Expr)
function eval(expr::Expr, env::Env)
    evalexpr(Val(expr.head), expr, env)
end

function eval(quoted::QuoteNode, env::Env)
    quoted.value
end

# default: throw error
function eval(expr, env::Env)
    throw("Could not evaluate " * string(expr) * ".")
end