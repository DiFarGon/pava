using Base: Bool
# defines the pavajulia function and some 
# useful functions for reading, writing

include("eval.jl")
include("exception.jl")

# prompt and read
function promptread() 
    begin
        print(">> ")
        readjuliaexp()
    end
end

# read a multi line Julia expression
function readjuliaexp()
    line = readline()
    parsed = Meta.parse(line)
    while isa(parsed, Expr) && parsed.head == :incomplete
        line = line * "\n" * readline()
        parsed = Meta.parse(line)
    end

    return line
end

# printing
function printobj(o)
    print(o)
end

function printobj(o::AbstractString)
    print('"', o, '"')
end

function printobj(o::Symbol)
    print(':', o)
end

function printobj(o::AbstractArray)
    print("[")
    
    for i in view(o, 1:length(o) - 1)
        printobj(i)
        print(", ")
    end

    printobj(o[end])
    print("]")
end

# main function
function pavajulia()
    top = initialenv()
    while (input = promptread()) != ""
        try 
            let parsed = Meta.parse(input),
                output = eval(parsed, top);
                printobj(output)
                println()
            end
        catch e
            println(e)
        end
    end
    println()
end